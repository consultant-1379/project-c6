package com.projectc6.gitreposerver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitreposerverApplicationTests {

	@Test
	void contextLoads() {
	}

}
