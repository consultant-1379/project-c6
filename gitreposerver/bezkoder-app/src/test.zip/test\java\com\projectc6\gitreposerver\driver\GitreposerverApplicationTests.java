package com.projectc6.gitreposerver.driver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitreposerverApplicationTests {

	@Test
	void contextLoads() {
		assert true;
	}

}
